import React from "react";

const StudentView = () => {
	return <div>StudentView</div>;
};

export default StudentView;
