import React , { useState } from 'react';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useForm } from 'react-hook-form';
import axios from 'axios';

const Login = ({ onLoginSuccess }) => {
    const { register, handleSubmit } = useForm();
    const [loading, setLoading] = useState(false);  
  
    const onSubmit = (data) => {        
      setLoading(true);  
      axios.post('https://2pf07kgt-8000.inc1.devtunnels.ms/auth/login/', data)
        .then(response => {
          const refreshToken = response.data["Refresh Token "];
          const accessToken = response.data["Access Token "];
          if (refreshToken && accessToken) {
            localStorage.setItem('refresh_token', refreshToken);
            localStorage.setItem('access_token', accessToken);
  
            toast.success("You have logged in successfully!");
            onLoginSuccess();
          } else {
            toast.error('Login failed. Please check your email, password, and role.');
          }
        })
        .catch(error => {
          console.error("Error", error);
          toast.error('Login failed. Please check your email, password, and role.');
        })
        .finally(() => {
          setLoading(false);  
        });
    };
  return (
    <>
    <div className='flex justify-center items-center min-h-screen bg-gray-100 text-black'>
    <div className='w-full max-w-md p-8 bg-white rounded-lg'>
      <h4 className="text-xl font-semibold text-center text-gray-700 mb-6">Log into your account</h4>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className='mb-4'>
          <input
            className='w-full px-3 py-2 bg-white border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500'
            type="email"
            placeholder='Enter Email'
            {...register('email')}
          />
        </div>
        <div className='mb-4'>
          <input
            className='w-full px-3 py-2 bg-white border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500'
            type="password"
            placeholder='Enter Password'
            {...register('password')}
          />
        </div>
        <div className='mb-6'>
          <select {...register('role')} className='w-full px-3 py-2 border bg-white rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500'>
            <option value="teacher">teacher</option>
            <option value="student">student</option>
            <option value="guardian">guardian</option>
            <option value="manager">manager</option>
          </select>
        </div>
        <button
          type="submit"
          className={`w-24 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 ${loading ? 'cursor-not-allowed opacity-50' : ''}`}
          disabled={loading}  
        >
          {loading ? 'Loading...' : 'Log In'} 
        </button>
        {loading && <span className="loading loading-spinner text-primary ml-4"></span>} 
      </form>
    </div>
  </div>
  </>
  )
}

export default Login