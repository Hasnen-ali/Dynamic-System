import React from "react";
import { NavLink } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

const Dropdown = ({ title, items, icon }) => {
	return (
		<>
			<div className="collapse collapse-arrow bg-white -my-3 !p-0  hover:text-white hover:bg-blue-600">
				<input type="checkbox" />
				<div className=" collapse-title-height collapse-title  items-center text-md font-small text-secondary-900 gap-x-3 flex">
					<FontAwesomeIcon icon={icon} />
					{title}
				</div>
				<div className="collapse-content">
					<ul>
						{items.map((item, index) => (
							<li key={index}>
								<NavLink
									to={item.path}
									className="pl-2 block py-1 rounded-md hover:text-white hover:bg-blue-400"
								>
									{item.label}
								</NavLink>
							</li>
						))}
					</ul>
				</div>
			</div>
		</>
	);
};

export default Dropdown;
