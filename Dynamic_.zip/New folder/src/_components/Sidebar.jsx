import React from "react";
import { NavLink } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
	faGraduationCap,
	faGear,
	faNewspaper,
	faBook,
	faTable,
	faCalendarDay,
	faCommentDollar,
	faClipboardList,
	faChalkboardUser,
	faHollyBerry,
	faBuilding,
	faBookOpenReader,
	faTableCellsLarge,
	faFileInvoiceDollar,
	faSchool,
} from "@fortawesome/free-solid-svg-icons";
import Dropdown from "../components/Dropdown";

import { ADMISSION, DIRECTOR, STUDENT, TEACHER } from "../routes/index";
import CustomNavLink from "../components/CustomNavLink";

function Sidebar({ isOpen }) {
	return (
		<>
			<div className="drawer lg:drawer-open">
				<input
					id="my-drawer-2"
					type="checkbox"
					className="drawer-toggle"
					checked={isOpen}
					readOnly
				/>
				<div className="drawer-content flex flex-col items-center justify-center">
					{/* Page content here */}

					<div>
						<div className="py-5 pl-5 px-3 text-gray-500">Main Menu</div>
						<ul className="sidebar-menu flex flex-col gap-y-6 pl-6 text-gray-500 w-56">
							<li>
								<CustomNavLink
									icon={faTableCellsLarge}
									label="Dashboard"
									path="/"
								/>
							</li>
							<li>
								<Dropdown
									title={"Admission"}
									items={[ADMISSION.LIST, ADMISSION.ADD]}
									icon={faSchool}
								/>
							</li>
							{/* Students dropdown */}
							<li>
								<Dropdown
									title="Students"
									items={[
										STUDENT.LIST,
										STUDENT.VIEW,
										STUDENT.ADD,
										STUDENT.EDIT,
									]}
									icon={faGraduationCap}
								/>
							</li>
							{/* Teacher dropdown */}
							<li>
								<Dropdown
									title="Teachers"
									items={[TEACHER.LIST]}
									icon={faChalkboardUser}
								/>
							</li>
							{/* Directors dropdown */}
							<li>
								<Dropdown
									title="Directors"
									items={[
										DIRECTOR.LIST,
										DIRECTOR.VIEW,
										DIRECTOR.ADD,
										DIRECTOR.EDIT,
									]}
									icon={faChalkboardUser}
								/>
							</li>
							{/* Departments dropdown */}
							<li>
								<NavLink to="/departments" className="flex items-center px-4">
									<FontAwesomeIcon icon={faBuilding} />
									<span className="ml-4">Departments</span>
								</NavLink>
							</li>
							<li>
								<NavLink to="/subjects" className="flex items-center px-4">
									<FontAwesomeIcon icon={faBookOpenReader} />
									<span className="ml-4">Subjects</span>
								</NavLink>
							</li>
						</ul>
						{/* Management menu start */}
						<div className="py-5 pl-5 px-3 text-gray-500">Management</div>
						<ul className="sidebar-menu space-y-7 pl-6 text-gray-500 mb-5">
							<li>
								<NavLink to="/accounts" className="flex items-center px-4">
									<FontAwesomeIcon icon={faFileInvoiceDollar} />
									<span className="ml-4">Accounts</span>
								</NavLink>
							</li>
							<li>
								<NavLink to="/holiday" className="flex items-center px-4">
									<FontAwesomeIcon icon={faHollyBerry} />
									<span className="ml-4">Holiday</span>
								</NavLink>
							</li>
							<li>
								<NavLink to="/fees" className="flex items-center px-4">
									<FontAwesomeIcon icon={faCommentDollar} />
									<span className="ml-4">Fees</span>
								</NavLink>
							</li>
							<li>
								<NavLink to="/examlist" className="flex items-center px-4">
									<FontAwesomeIcon icon={faClipboardList} />
									<span className="ml-4">Exam List</span>
								</NavLink>
							</li>
							<li>
								<NavLink to="/events" className="flex items-center px-4">
									<FontAwesomeIcon icon={faCalendarDay} />
									<span className="ml-4">Events</span>
								</NavLink>
							</li>
							<li>
								<NavLink to="/timetable" className="flex items-center px-4">
									<FontAwesomeIcon icon={faTable} />
									<span className="ml-4">Time Table</span>
								</NavLink>
							</li>
							<li>
								<NavLink to="/library" className="flex items-center px-4">
									<FontAwesomeIcon icon={faBook} />
									<span className="ml-4">Library</span>
								</NavLink>
							</li>
							<li>
								<NavLink to="/blog" className="flex items-center px-4">
									<FontAwesomeIcon icon={faNewspaper} />
									<span className="ml-4">Blog</span>
								</NavLink>
							</li>
							<li>
								<NavLink to="/settings" className="flex items-center px-4">
									<FontAwesomeIcon icon={faGear} />
									<span className="ml-4">Settings</span>
								</NavLink>
							</li>
							 {/* Login link */}
							 <li>
                                <NavLink to="/login" className="flex items-center px-4">
                                    <FontAwesomeIcon icon={faGear} />
                                    <span className="ml-4">Login</span>
                                </NavLink>
                            </li>
						</ul>
						{/* Management menu end */}
					</div>
				</div>
			</div>
		</>
	);
}

export default Sidebar;
