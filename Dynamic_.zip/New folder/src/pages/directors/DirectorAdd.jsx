import React, { useState } from 'react'
import axios from 'axios';

const DirectorAdd = () => {
  const [formData, setFormData] = useState({
    first_name: '',
    middle_name: '',
    last_name: '',
    email: '',
    password: '',
    phone_number: '',
    gender: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://your-backend-url/api/directors', formData);
      console.log('Director added successfully:', response.data);
    } catch (error) {
      console.error('Error adding director:', error);
    }
  };
  return (
    <>
     <form  onSubmit={handleSubmit} >
        <div className="grid grid-cols-3 grid-rows-1 gap-4 mx-8">
          <h2 className="text-xl text-left my-10 font-semibold mb-4 md:col-span-3 text-black">Basic Details</h2>
          <div >
            <label className="form-control w-full max-w-xs">
              <div className="label">
              </div>
              <input type="text"
                placeholder="First Name"
                name="first_name"
                value={formData.first_name}
                onChange={handleChange}
                className="input w-full max-w-xs hover:border-gray-950 border-2 border-gray-400 bg-white text-black" />
              <div className="label">
              </div>
            </label>
          </div>
          <div >
            <label className="form-control w-full max-w-xs">
              <div className="label">
              </div>
              <input type="text"
                placeholder="Second Name"
                name="middle_name"
                value={formData.middle_name}
                onChange={handleChange}
                className="input w-full max-w-xs hover:border-gray-950 border-2 border-gray-400 bg-white text-black" />
              <div className="label">
              </div>
            </label>
          </div>
          <div >
            <label className="form-control w-full max-w-xs">
              <div className="label">
              </div>
              <input type="text"
                placeholder="Last Name"
                name="last_name"
                value={formData.last_name}
                onChange={handleChange}
                className="input w-full max-w-xs hover:border-gray-950 border-2 border-gray-400 bg-white text-black" />
              <div className="label">
              </div>
            </label>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 px-4 my-8 mx-4">
          <h2 className="text-xl text-left mx-2 font-semibold mb-4 md:col-span-2 text-black">Login Details</h2>
          <div className="flex flex-col mb-4 firstLine">
            <label className="form-control w-full max-w-xs">
              <div className="label">
              </div>
              <input type="email"
                placeholder="Enter E-mail ID"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="input w-[550px] h-[45px] hover:border-gray-950 border-2 border-gray-400 bg-white text-black" />
              <div className="label">
              </div>
            </label>
             <label className="form-control w-full max-w-xs">
              <div className="label">
              </div>
              <input type="number"
                 placeholder="Enter Phone number"
                 name="phone_number"
                 value={formData.phone_number}
                onChange={handleChange}
                className="input w-[550px] h-[45px] hover:border-gray-950 border-2 border-gray-400 bg-white text-black" />
              <div className="label">
              </div>
            </label>
          </div>
          <div className="flex flex-col mb-4 secondLine">
            <label className="form-control w-full max-w-xs">
              <div className="label">
              </div>
              <input type="password"
                placeholder="Enter Password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                className="input w-[550px] h-[45px] hover:border-gray-950 border-2 border-gray-400 bg-white text-black" />
              <div className="label">
              </div>
            </label>
             <label className="form-control w-full max-w-xs">
              <div className="label">
              </div>
              <input type="text"
                 placeholder="Enter gender"
                 name="gender"
                 value={formData.gender}
                 onChange={handleChange}
                className="input w-[550px] h-[45px] hover:border-gray-950 border-2 border-gray-400 bg-white text-black" />
              <div className="label">
              </div>
            </label>
          </div>
        </div>

        <div className="text-left mx-8 mb-10">
          <button className="btn py-2 px-10 bg-blue-600  hover:bg-blue-400 font-bold text-white rounded-lg  mr-12 text-base">Submit</button>
        </div>

      </form>
    </>
  )
}

export default DirectorAdd
