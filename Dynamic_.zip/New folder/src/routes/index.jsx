import DirectorAdd from "../pages/directors/DirectorAdd";
import DirectorEdit from "../pages/directors/DirectorEdit";
import DirectorList from "../pages/directors/DirectorList";
import DirectorView from "../pages/directors/DirectorView";

import StudentAdd from "../pages/students/StudentAdd";
import StudentEdit from "../pages/students/StudentEdit";
import StudentList from "../pages/students/StudentList";
import StudentView from "../pages/students/StudentView";

import TeacherAdd from "../pages/teachers/TeacherAdd";
import TeacherEdit from "../pages/teachers/TeacherEdit";
import TeacherList from "../pages/teachers/TeacherList";
import TeacherView from "../pages/teachers/TeacherView";

import AdmissionAdd from "../pages/admission/AdmissionAdd";
import AdmissionList from "../pages/admission/AdmissionList";


const DIRECTOR = {
	ADD: {
		path: "/director/add",
		label: "Director Add",
		component: <DirectorAdd />,
	},
	EDIT: {
		path: "/director/:id/edit",
		label: "Director Edit",
		component: <DirectorEdit />,
	},
	LIST: {
		path: "/directors",
		label: "Director List",
		component: <DirectorList />,
	},
	VIEW: {
		path: "/director/:id",
		label: "Director Details",
		component: <DirectorView />,
	},
};

const STUDENT = {
	ADD: {
		path: "/students/add",
		label: "Student Add",
		component: <StudentAdd />,
	},
	EDIT: {
		path: "/students/:id/edit",
		label: "Student Edit",
		component: <StudentEdit />,
	},
	LIST: {
		path: "/students",
		label: "Student List",
		component: <StudentList />,
	},
	VIEW: {
		path: "/students/:id",
		label: "Student Details",
		component: <StudentView />,
	},
};

const TEACHER = {
	ADD: {
		path: "/teachers/add",
		label: "Teacher Add",
		component: <TeacherAdd />,
	},
	EDIT: {
		path: "/teachers/:id/edit",
		label: "Teacher Edit",
		component: <TeacherEdit />,
	},
	LIST: {
		path: "/teachers",
		label: "Teacher List",
		component: <TeacherList />,
	},
	VIEW: {
		path: "/teachers/:id",
		label: "Teacher Details",
		component: <TeacherView />,
	},
};

const ADMISSION = {
	ADD: {
		path: "/admission/add",
		label: "Admission Add",
		component: <AdmissionAdd />,
	},
	LIST: {
		path: "/admission",
		label: "Admission List",
		component: <AdmissionList />,
	},
};

// const LOGIN = {
//     PATH: {
//         path: "/login",
//         label: "Login",
//         component: <Login />,
//     },
// };

export { DIRECTOR, STUDENT, TEACHER, ADMISSION  };
