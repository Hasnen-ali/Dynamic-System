import React from "react";

export default function TeacherEdit() {
	return <div></div>;
}
