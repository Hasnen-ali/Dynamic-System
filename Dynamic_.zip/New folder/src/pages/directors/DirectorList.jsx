import React, { useState, useEffect } from "react";
import Table1 from "../../components/Table";
import axios from "axios";

const DirectorList = () => {
	const [searchId, setSearchId] = useState("");
	const [searchName, setSearchName] = useState("");
	const [searchPhone, setSearchPhone] = useState("");
	const [directors, setDirectors] = useState([]);

	useEffect(() => {
		fetchData();
	}, []);

	const fetchData = async () => {
		try {
			const response = await axios.get("http://127.0.0.1:8000/directors/");
			setDirectors(response.data);
		} catch (error) {
			console.error("Error fetching data:", error);
		}
	};

	const handleSearch = () => {
		console.log("Searching...");
	};

	const columns = [
		"id",
		"first_name",
		"middle_name",
		"last_name",
		"gender",
		"phone_number",
		"email",
	];
	return (
		<>
			<div className="grid grid-cols-7 grid-rows-1 gap-5 mx-5 my-6">
				<div className="col-span-2">
					<label className="form-control w-full max-w-xs">
						<div className="label"></div>
						<input
							type="text"
							placeholder="Search by ID"
							className="input w-full max-w-xs hover:border-gray-950 border-2 border-gray-400 bg-white text-black"
							value={searchId}
							onChange={(e) => setSearchId(e.target.value)}
						/>
						<div className="label"></div>
					</label>
				</div>
				<div className="col-span-2 col-start-3">
					<label className="form-control w-full max-w-xs ">
						<div className="label"></div>
						<input
							type="text"
							placeholder="Search by Name"
							className="input w-full max-w-xs hover:border-gray-950 border-2 border-gray-400 bg-white text-black"
							value={searchName}
							onChange={(e) => setSearchName(e.target.value)}
						/>
						<div className="label"></div>
					</label>
				</div>
				<div className="col-span-2 col-start-5">
					<label className="form-control w-full max-w-xs">
						<div className="label"></div>
						<input
							type="text"
							placeholder="Search by Phone"
							className="input w-full max-w-xs hover:border-gray-950 border-2 border-gray-400 bg-white text-black"
							value={searchPhone}
							onChange={(e) => setSearchPhone(e.target.value)}
						/>
						<div className="label"></div>
					</label>
				</div>
				<div className="col-start-7">
					<button
						className="btn py-2 px-10 bg-blue-600  hover:bg-blue-400 font-bold text-white rounded-lg my-4 mr-12 text-base"
						onClick={handleSearch}
					>
						Search
					</button>
				</div>
			</div>

			<div className="mt-5">
				<Table1 columns={columns} data={directors} />
			</div>
		</>
	);
};

export default DirectorList;
