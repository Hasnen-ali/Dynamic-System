import React from "react";
import Table from "../../components/Table";

const TeacherList = () => {
	let columns = ["id", "hii", "hello", "top"];

	let data = [
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
		{
			id: 1,
			hii: "dhjdhkdj",
			hello: "kjhfkhd",
			top: "dhdkjhkd",
		},
	];
	return (
		<>
			<Table columns={columns} data={data} />
		</>
	);
};

export default TeacherList;
