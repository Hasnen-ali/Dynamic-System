import React from "react";
import axios from "axios";
import { toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';

export default function Dashboard({ onLogout }) {
	const handleLogout = () => {
		const refresh_token = localStorage.getItem("refresh_token");
	
		if (refresh_token) {
		  axios.post("https://2pf07kgt-8000.inc1.devtunnels.ms/auth/logout/", { refresh_token })
			.then((response) => {
			  localStorage.clear();
	
			  toast.success("Logged out successfully!");
	
			  onLogout();
			})
			.catch((error) => {
				
			  console.error("Error logging out", error);
			  toast.error("Error logging out. Please try again.");
			});
		} else {
		  console.log("No refresh token found");
		  toast.error("No refresh token found. Please log in again.");
		}
	  };

	return (
		<>
		<div className="text-black text-2xl font-bold">
		  <h1>You are successfully logged in</h1>
		</div>
		<button
		  onClick={handleLogout}
		  className="w-24 py-2 mt-6 bg-blue-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
		>
		  Log out
		</button>
	  </>
	);
}
