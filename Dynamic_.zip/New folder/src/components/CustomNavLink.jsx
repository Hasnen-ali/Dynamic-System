import React from "react";
import { NavLink } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

export default function CustomNavLink({ icon, label, path }) {
	return (
		<NavLink to={path} className="flex items-center px-4">
			<FontAwesomeIcon icon={icon} />
			<span className="ml-4">{label}</span>
		</NavLink>
	);
}
