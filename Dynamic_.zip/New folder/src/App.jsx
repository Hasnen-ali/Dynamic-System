import React, { useState, useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Dashboard from './pages/Dashboard.jsx';
import { DIRECTOR, TEACHER, STUDENT, ADMISSION } from "./routes/index.jsx";
import DefaultLayout from './_components/DefaultLayout.jsx';
import Login from './pages/Login.jsx';

function App() {
    const [isAuthenticated, setIsAuthenticated] = useState(false);

    useEffect(() => {
        const accessToken = localStorage.getItem("access_token");
        if (accessToken) {
            setIsAuthenticated(true);
        }
    }, []);

    return (
		<>
            <ToastContainer
                position="top-right"
                autoClose={3000}
                hideProgressBar={false}
                newestOnTop={true}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                limit={1}
            />
            <Routes>
                {!isAuthenticated ? (
                    <Route path="/login" element={<Login onLoginSuccess={() => setIsAuthenticated(true)} />} />
                ) : (
                    <Route path="/" element={<DefaultLayout/>}>
                        {/* Dashboard route */}
                        <Route index element={<Dashboard onLogout={() => setIsAuthenticated(false)} />} />

                        {/* Admission routes */}
                        <Route path={ADMISSION.LIST.path} element={ADMISSION.LIST.component} />
                        <Route path={ADMISSION.ADD.path} element={ADMISSION.ADD.component} />

                        {/* Director routes */}
                        <Route path={DIRECTOR.LIST.path} element={DIRECTOR.LIST.component} />
                        <Route path={DIRECTOR.VIEW.path} element={DIRECTOR.VIEW.component} />
                        <Route path={DIRECTOR.EDIT.path} element={DIRECTOR.EDIT.component} />
                        <Route path={DIRECTOR.ADD.path} element={DIRECTOR.ADD.component} />

                        {/* Student routes */}
                        <Route path={STUDENT.LIST.path} element={STUDENT.LIST.component} />
                        <Route path={STUDENT.VIEW.path} element={STUDENT.VIEW.component} />
                        <Route path={STUDENT.EDIT.path} element={STUDENT.EDIT.component} />
                        <Route path={STUDENT.ADD.path} element={STUDENT.ADD.component} />

                        {/* Teacher routes */}
                        <Route path={TEACHER.LIST.path} element={TEACHER.LIST.component} />
                        <Route path={TEACHER.VIEW.path} element={TEACHER.VIEW.component} />
                        <Route path={TEACHER.EDIT.path} element={TEACHER.EDIT.component} />
                        <Route path={TEACHER.ADD.path} element={TEACHER.ADD.component} />
                    </Route>
                )}
                <Route path="*" element={<Navigate to={isAuthenticated ? "/" : "/login"} replace />} />
            </Routes>
			</>
    );
}

export default App;
