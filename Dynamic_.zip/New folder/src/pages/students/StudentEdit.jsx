import React from "react";

const StudentEdit = () => {
	return (
		<>
			<div className="text-left text-black text-2xl">
				<h1>Edit Student</h1>
			</div>
			<hr />
			<div className="grid grid-cols-6 grid-rows-1 gap-4">
				{/* laft side */}
				<div className="col-span-3"></div>
				{/* right side */}
				<div className="col-span-3 col-start-4"></div>
			</div>
		</>
	);
};

export default StudentEdit;
