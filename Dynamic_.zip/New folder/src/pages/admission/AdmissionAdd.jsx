import React from "react";

const AdmissionAdd = () => {
	return (
		<>
			<div className="text-black text-2xl font-bold">
				<h1>Admission Form</h1>
			</div>
		</>
	);
};

export default AdmissionAdd;
