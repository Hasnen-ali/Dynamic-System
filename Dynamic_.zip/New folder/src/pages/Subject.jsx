import React from "react";

const Subject = () => {
	return <div>Subject</div>;
};

export default Subject;
