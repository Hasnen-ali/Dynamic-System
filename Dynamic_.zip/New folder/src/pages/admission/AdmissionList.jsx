import React from "react";

const AdmissionList = () => {
	return (
		<>
			<div className="text-black text-2xl font-bold">
				<h1>Admission List</h1>
			</div>
		</>
	);
};

export default AdmissionList;
