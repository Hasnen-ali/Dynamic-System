import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBell, faExpand } from "@fortawesome/free-solid-svg-icons";
import SearchBar from "../components/SearchBar";

const Header = ({ toggleSideBar }) => {
	return (
		<>
			<div className="navbar bg-white w-full">
				{/* logo */}
				<div className="flex-1 ml-5">
					<span className="flex items-center ">
						<img
							src="https://thumbs.dreamstime.com/b/globe-world-education-logo-kids-bright-children-school-books-kids-icon-globe-world-education-bright-logo-children-school-home-roof-168110808.jpg"
							className="h-10 mix rounded-lg"
							alt="Logo"
						/>
						<h2 className="text-2xl text-black cursor-pointer hidden lg:block md:block">
							<span className="font-bold text-black">My</span>
							School
						</h2>
					</span>
					{/* Bars Icon */}
					<div className="flex-none ml-10 text-white ">
						<button
							className="btn btn-square btn-ghost bg-blue-600  hover:bg-sky-700 text-white"
							onClick={toggleSideBar}
						>
							<svg
								xmlns="http://www.w3.org/2000/svg"
								fill="none"
								viewBox="0 0 24 24"
								className="inline-block h-5 w-5 stroke-current"
							>
								<path
									strokeLinecap="round"
									strokeLinejoin="round"
									strokeWidth="2"
									d="M4 6h16M4 12h16M4 18h16"
								></path>
							</svg>
						</button>
					</div>
					{/* Search bar */}

					<SearchBar />
				</div>
				{/* Navigation Icons */}
				<div>
					<ul className="flex gap-x-8">
						{/* Avatar */}
						<li>
							<div>
								<img
									className="h-10 rounded-full bg-slate-100 p-2"
									src="https://i.pinimg.com/736x/04/fd/25/04fd255a777fa3a6361574f0ee2f1f8e.jpg"
									alt=""
								/>
							</div>
						</li>
						{/* Bell Icon */}
						<li>
							<div>
								<FontAwesomeIcon
									className="rounded-full bg-slate-100 p-2 cursor-pointer text-white h-6"
									style={{ color: "#050505" }}
									icon={faBell}
								/>
							</div>
						</li>
						{/* Expand Icon */}
						<li className="hidden lg:block  md:block ">
							<div className="w-8 h-8">
								<FontAwesomeIcon
									className="rounded-full bg-slate-100 p-2 cursor-pointer text-white h-6"
									style={{ color: "#050505" }}
									icon={faExpand}
								/>
							</div>
						</li>
						{/* User Avatar and Dropdown */}
						<li>
							<div className="h-10 flex items-center space-x-2">
								<img
									className="h-full w-full rounded-full object-contain   "
									src="https://images.unsplash.com/photo-1568602471122-7832951cc4c5?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
									alt=""
								/>
								<div className="text-sm hidden lg:block  md:block ">
									<h1 className="font-bold text-black">Prince Harry</h1>
									{/* Dropdown */}
									<select className=" text-blue-700 bg-white font-bold">
										<option value="administrator">Administrator</option>
										<option value="profile">Profile</option>
										<option value="input">Input</option>
										<option value="logout">Logout</option>
									</select>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</>
	);
};

export default Header;
